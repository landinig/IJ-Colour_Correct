import ij.*;
import ij.plugin.filter.PlugInFilter;
import ij.process.*;
import ij.gui.*;
import java.awt.*;

public class Colour_Correct implements PlugInFilter {

	public int setup(String arg, ImagePlus imp) {
		if (arg.equals("about"))
			{showAbout(); return DONE;}
		return DOES_RGB;
	}

	public void run(ImageProcessor ip) {
		int [] xyzf = new int [4]; //[0]=x, [1]=y, [2]=z, [3]=flags
		int xe = ip.getWidth();
		int ye = ip.getHeight();
		int x, y, p=0;
		int nblack=0, blackred=0, blackgreen=0, blackblue=0;
		int nwhite=0, whitered=0, whitegreen=0, whiteblue=0;

		double avwhitered=1.0, avwhitegreen=1.0, avwhiteblue=1.0;
		double avblackred=0, avblackgreen=0, avblackblue=0;
		
		int tred, tgreen, tblue;
		ImagePlus imp = WindowManager.getCurrentImage();
		imp.getCanvas().disablePopupMenu(true);

		IJ.showMessage("Colour Correct v1.5 by G.Landini\n \nSelect BLACK points (right-click to end)");
		IJ.setTool(12);

		getCursorLoc(xyzf, imp);

		while ((xyzf[3] & 4) == 0){//right not pressed
			getCursorLoc( xyzf, imp );
			if ((xyzf[3] & 16) !=0 ){ //left pressed
				x = xyzf[0];
				y = xyzf[1];

				imp.setRoi(new PointRoi(x, y));
				p=ip.getPixel(x,y);

				nblack ++;
				blackred   += (p & 0xff0000) >>16;
				blackgreen += (p & 0x00ff00) >>8 ;
				blackblue  +=  p & 0x0000ff;

				while ((xyzf[3] & 16) != 0){  //trap until left released
					getCursorLoc(xyzf, imp);
					IJ.wait(20);
				}
			}
			IJ.wait(20);
		}

		IJ.run("Select None");
		if (nblack > 0){
			avblackred   = (double)blackred   / (double)nblack;
			avblackgreen = (double)blackgreen / (double)nblack;
			avblackblue  = (double)blackblue  / (double)nblack;
		}

		IJ.showMessage("Now select WHITE points (right-click to end)");

		getCursorLoc(xyzf, imp);
		while ((xyzf[3] & 4) !=0){   //trap until right released
			getCursorLoc(xyzf, imp);
			IJ.wait(20);
		}

		while ((xyzf[3] & 4) == 0){//until right pressed
			getCursorLoc( xyzf, imp );
			if ((xyzf[3] & 16) != 0 ){ //left pressed
				x=xyzf[0];
				y=xyzf[1];

				imp.setRoi(new PointRoi(x, y));
				p=ip.getPixel(x,y);

				nwhite++;
				whitered   += (p & 0xff0000) >> 16;
				whitegreen += (p & 0x00ff00) >> 8;
				whiteblue  +=  p & 0x0000ff;
				while ((xyzf[3] & 16) != 0){  //trap until left released
					getCursorLoc(xyzf, imp);
					IJ.wait(20);
				}
			}
			IJ.wait(20);
		}

		IJ.run("Select None");
		if (nwhite > 0){
			avwhitered   = ((double)whitered   / (double)nwhite) - avblackred;
			avwhitegreen = ((double)whitegreen / (double)nwhite) - avblackgreen;
			avwhiteblue  = ((double)whiteblue  / (double)nwhite) - avblackblue;
		}
		else {
			avwhitered = avwhitegreen = avwhiteblue = 255.0;
		}
		
		
		
		for(y = 0; y < ye; y++){
			for (x = 0; x < xe; x++){
				p=ip.getPixel(x, y);
				tred =   (int) Math.floor(((((double)((p & 0xff0000) >> 16) - avblackred)   / avwhitered)   * 255.0) + 0.5);
				if (tred < 0) tred = 0; else if (tred > 255) tred = 255;

				tgreen = (int) Math.floor(((((double)((p & 0x00ff00) >> 8)  - avblackgreen) / avwhitegreen) * 255.0) + 0.5);
				if (tgreen < 0) tgreen = 0; else if (tgreen > 255) tgreen = 255;

				tblue =  (int) Math.floor(((((double)((p & 0x0000ff)     )  - avblackblue)  / avwhiteblue)  * 255.0) + 0.5);
				if (tblue < 0) tblue = 0; else if (tblue > 255) tblue = 255;

				ip.putPixel(x,y, ((tred & 0xff) << 16)+ ((tgreen & 0xff) << 8) + (tblue & 0xff));
			}
		}
		//IJ.log("black: " +avblackred+" "+ avblackgreen+" "+ avblackblue+" white: "+avwhitered+" "+ avwhitegreen+" "+ avwhiteblue);
		imp.getCanvas().disablePopupMenu(false);
		imp.updateAndDraw();
	}

	void getCursorLoc(int [] xyzf, ImagePlus imp ) {
		ImageWindow win = imp.getWindow();
		ImageCanvas ic = win.getCanvas();
		Point p = ic.getCursorLoc();
		xyzf[0]=p.x;
		xyzf[1]=p.y;
		xyzf[2]=imp.getCurrentSlice()-1;
		xyzf[3]=ic.getModifiers();
	}

	void showAbout() {
		IJ.showMessage("About Colour_Correct...",
		"Colour_Correct by Gabriel Landini,  G.Landini@bham.ac.uk\n"+
		"Corrects the colours of an image by first subtracting the mean RGB values of\n"+
		"a number of points considered to be \'black\' and then subtracts the background\n"+
		"by performing the ratio of the image and the mean RGB values of a number of points\n"+
		"considered to be \'white\' minus the \'black\'. It does *not* correct for uneven\n"+
		"illumination.  The formula is:"+
		"           image = [(original-black)/(white-black)]*255\n"+
		"This is a simple & quick (not the best, though) method to compensate the filament\n"+
		"temperature colour of light transmitted images such as bright field microscopy\n"+
		"when there is no original illumination source to correct from.");
	}
}

